
chrome.devtools.panels.elements.createSidebarPane('Sencha Component Locator',
    function(sidebar) {
        sidebar.setPage('app.html');
        sidebar.setHeight('300px');
    });