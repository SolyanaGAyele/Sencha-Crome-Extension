Ext.define('CL.data.LocatorStore', {
    extend: 'Ext.data.Store',

    storeId: 'locatorStore',

    fields: ['locator', 'matches']
});